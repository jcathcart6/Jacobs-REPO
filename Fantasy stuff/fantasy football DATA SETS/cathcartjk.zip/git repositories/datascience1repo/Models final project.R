#Loading Necessary Packages
library(readxl)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(gridExtra)
library(grid)


#Data filtering and cleaning
crimedata <- read_excel("crimedata.xlsx") %>%
  rename(crimerate = "Violent crimes per 100,000 population", 
         poverty = "% of persons below the poverty level",
         education = "% of persons 25 or older with at least a bachelor's degree",
         unemployment = "Uneployment rate")


#boxplots to see if there are outliers
ggplot(crimedata, aes(x = 1, y = unemployment)) +
  geom_boxplot()

ggplot(crimedata, aes(x = 1, y = poverty)) +
  geom_boxplot()

ggplot(crimedata, aes(x = 1, y = education)) +
  geom_boxplot()

ggplot(crimedata, aes(x = 1, y = crimerate)) +
  geom_boxplot()

#filtering out outliers from crime rate
fivenum <- fivenum(crimedata$crimerate)
iqr <- IQR(crimedata$crimerate)
lower = fivenum[2] - 1.5 * iqr
upper = fivenum[4] + 1.5 * iqr


crimedata2 <- crimedata %>%
  filter(crimerate <= upper)

#Without DC

p1 <- ggplot(crimedata2, aes(x = poverty , y = crimerate)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                  box.padding   = 0.35, 
                  point.padding = 0.5,
                  segment.color = 'grey50',
                  size = 2.5) +
  ggtitle("Crime Rate Versus Poverty") +
  xlab("Percent of Population Below the Poverty Line") +
  ylab("Viloent Crimes Per 100,000 People")

p2 <- ggplot(crimedata2, aes(x = education , y = crimerate)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                   box.padding   = 0.35, 
                   point.padding = 0.5,
                   segment.color = 'grey50',
                   size = 2.5) +
  ggtitle("Crime Rate Versus Education") +
  xlab("Percent of Under 25 year olds with a Bachelors Degree") +
  ylab("Viloent Crimes Per 100,000 People")

p3 <- ggplot(crimedata2, aes(x = unemployment, y = crimerate, label = State)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                  box.padding   = 0.35, 
                  point.padding = 0.5,
                  segment.color = 'grey50',
                  size = 2.5) +
  ggtitle("Crime Rate Versus Unemployment") +
  xlab("Unemployment Rate") +
  ylab("Viloent Crimes Per 100,000 People")

#With DC

p4 <- ggplot(crimedata, aes(x = poverty , y = crimerate)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                  box.padding   = 0.35, 
                  point.padding = 0.5,
                  segment.color = 'grey50',
                  size = 2.5) +
  ggtitle("Crime Rate Versus Poverty") +
  xlab("Percent of Population Below the Poverty Line") +
  ylab("Viloent Crimes Per 100,000 People")

p5 <- ggplot(crimedata, aes(x = education , y = crimerate)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                  box.padding   = 0.35, 
                  point.padding = 0.5,
                  segment.color = 'grey50',
                  size = 2.5) +
  ggtitle("Crime Rate Versus Education") +
  xlab("Percent of Under 25 year olds with a Bachelors Degree") +
  ylab("Viloent Crimes Per 100,000 People")

p6 <- ggplot(crimedata, aes(x = unemployment, y = crimerate, label = State)) +
  geom_point() +
  geom_smooth() +
  geom_text_repel(aes(label = State),
                  box.padding   = 0.35, 
                  point.padding = 0.5,
                  segment.color = 'grey50',
                  size = 2.5) +
  ggtitle("Crime Rate Versus Unemployment") +
  xlab("Unemployment Rate") +
  ylab("Viloent Crimes Per 100,000 People")


grid.arrange(p1,p2,p3)
