# Mauna Loa data from https://www.esrl.noaa.gov/gmd/ccgg/trends/data.html

CO2monthlyM <- read.table(file=url("ftp://aftp.cmdl.noaa.gov/products/trends/co2/co2_mm_mlo.txt"))
colnames(CO2monthlyM) <- c("year", "month", "decimaldate", "average", "interpolated", "trend", "numdays")
write.csv(CO2monthlyM, file = "CO2monthlyM.csv", row.names = FALSE)


# Powerball Lottery data from https://catalog.data.gov/dataset/lottery-powerball-winning-numbers-beginning-2010

# tidyverse packages
# https://www.tidyverse.org/packages/
library(tidyr)
library(tidyverse)
library(dplyr)
library(magrittr)
library(lubridate)
powerball1 <- read.csv("https://data.ny.gov/api/views/d6yy-54nr/rows.csv")
str(powerball1)
write.csv(powerball1, file = "powerballdata/rawpowerball.csv", row.names = FALSE)

powerball2 <- powerball1 %>% 
  separate(Winning.Numbers, c("w1", "w2", "w3", "w4", "w5", "red"))
str(powerball2)

powerball3 <- powerball2 %<>% 
  mutate_if(is.character, as.integer)
str(powerball3)

powerball4 <- powerball3 %>% 
  mutate(Draw.Date = mdy(Draw.Date))
str(powerball4)

powerball5 <- powerball4 %>% 
  rename(drawdate = Draw.Date, multiplier = Multiplier)
str(powerball5)

powerballred <- powerball5 %>% 
  select(drawdate, red)
str(powerballred)

# gather and spread
# https://tidyr.tidyverse.org/

powerballwhite <- powerball5 %>% 
  select(drawdate:w5) %>% 
  gather(ballnum, number, w1:w5)
str(powerballwhite)


# read_excel
# https://readxl.tidyverse.org/reference/read_excel.html

library(readxl)
url <- "https://stat-jet-asu.github.io/DataScience1/Projects/Past/powerball.xlsx"
download.file(url, "powerball.xlsx")
powerballSh1 <- read_excel(destfile, sheet = 1)
powerballSh2 <- read_excel(destfile, sheet = 2)
powerballSh3 <- read_excel(destfile, sheet = 3)
powerballSh4 <- read_excel(destfile, sheet = 4)
str(powerballSh1)
str(powerballSh2)
str(powerballSh3)
str(powerballSh4)
Last modified: Tuesday, November 6, 2018, 2:32 PM