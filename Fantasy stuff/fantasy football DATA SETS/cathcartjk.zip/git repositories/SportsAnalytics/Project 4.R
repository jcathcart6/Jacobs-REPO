library(dplyr)
library(readxl)
library(cluster)

boston <- read_excel("fiveTeams.xlsx", sheet = 1)
newyork <- read_excel("fiveTeams.xlsx", sheet = 2)
cleveland <- read_excel("fiveTeams.xlsx", sheet = 3)
chicago <- read_excel("fiveTeams.xlsx", sheet = 4)
philly <- read_excel("fiveTeams.xlsx", sheet = 5)

#Data reprocessing changing 2B to secondB and 3b to thirdB
names(boston)[18] <- "secondB"
names(boston)[19] <- "thirdB"
names(newyork)[18] <- "secondB"
names(newyork)[19] <- "thirdB"
names(cleveland)[18] <- "secondB"
names(cleveland)[19] <- "thirdB"
names(chicago)[18] <- "secondB"
names(chicago)[19] <- "thirdB"
names(philly)[18] <- "secondB"
names(philly)[19] <- "thirdB"

#runs divided by ERA
boston <- boston %>% 
  mutate( runsDera = R /ERA)
newyork <- newyork %>% 
  mutate( runsDera = R /ERA)
cleveland <- cleveland %>% 
  mutate( runsDera = R /ERA)
chicago <- chicago %>% 
  mutate( runsDera = R /ERA)
philly <- philly %>% 
  mutate( runsDera = R /ERA)

# #Slugging Percentage
# boston <- boston %>%
#   mutate(OPS = (((H + secondB + 2*thirdB + 3*HR)/AB) + ((H + BB + HBP)/(AB + BB + SF + HBP))))
# newyork <- newyork %>%
#   mutate(OPS = (((H + secondB + 2*thirdB + 3*HR)/AB) + ((H + BB + HBP)/(AB + BB + SF + HBP))))
# cleveland <- cleveland %>%
#   mutate(OPS = (((H + secondB + 2*thirdB + 3*HR)/AB) + ((H + BB + HBP)/(AB + BB + SF + HBP))))
# chicago <- chicago %>%
#   mutate(OPS = (((H + secondB + 2*thirdB + 3*HR)/AB) + ((H + BB + HBP)/(AB + BB + SF + HBP))))
# philly <- philly %>%
#   mutate(OPS = (((H + secondB + 2*thirdB + 3*HR)/AB) + ((H + BB + HBP)/(AB + BB + SF + HBP))))

#errors per game
boston <- boston %>% 
        mutate(err_gp = (ER/G))
newyork <- newyork %>% 
  mutate(err_gp = (ER/G))
cleveland <- cleveland %>% 
  mutate(err_gp = (ER/G))
chicago <- chicago %>% 
  mutate(err_gp = (ER/G))
philly <- philly %>% 
  mutate(err_gp = (ER/G))

#hit per homerun
boston <- boston %>%
  mutate(hits_hr = (H/HR)/G)
newyork <- newyork %>%
  mutate(hits_hr = (H/HR)/G)
cleveland <- cleveland %>%
  mutate(hits_hr = (H/HR)/G)
chicago <- chicago %>%
  mutate(hits_hr = (H/HR)/G)
philly <- philly %>%
  mutate(hits_hr = (H/HR)/G)


#wins minus homegames

boston <- boston %>% 
  mutate(winMhomegames = W - Ghome)
newyork <- newyork %>% 
  mutate(winMhomegames = W - Ghome)
cleveland <- cleveland %>% 
  mutate(winMhomegames = W - Ghome)
chicago <- chicago %>% 
  mutate(winMhomegames = W - Ghome)
philly <- philly %>% 
  mutate(winMhomegames = W - Ghome)





#hr per hra

boston <- boston %>%
  mutate(hr_hra = (HR/HRA)/G)
newyork <- newyork %>%
  mutate(hr_hra = (HR/HRA)/G)
cleveland <- cleveland %>%
  mutate(hr_hra = (HR/HRA)/G)
chicago <- chicago %>%
  mutate(hr_hra = (HR/HRA)/G)
philly <- philly %>%
  mutate(hr_hra = (HR/HRA)/G)



# hits divided by hits allowed

boston <- boston %>%
  mutate(hitsDIVhitallow = (H/HA)/G)
newyork <- newyork %>%
  mutate(hitsDIVhitallow = (H/HA)/G)
cleveland <- cleveland %>%
  mutate(hitsDIVhitallow = (H/HA)/G)
chicago <- chicago %>%
  mutate(hitsDIVhitallow = (H/HA)/G)
philly <- philly %>%
  mutate(hitsDIVhitallow = (H/HA)/G)

#stolen base per caught stealing

boston <- boston %>%
  mutate(sb_cs = (SB/CS)/G)
newyork <- newyork %>%
  mutate(sb_cs = (SB/CS)/G)
cleveland <- cleveland %>%
  mutate(sb_cs = (SB/CS)/G)
chicago <- chicago %>%
  mutate(sb_cs = (SB/CS)/G)
philly <- philly %>%
  mutate(sb_cs = (SB/CS)/G)


names(boston)


boston <- boston %>%
  mutate(hr_hra = (HR/HRA)/G)

#Boston cluster

boston_7 <- boston %>%
  select("yearID","ERA", "runsDera", "sb_cs", "err_gp", "hits_hr", "winMhomegames", "hr_hra")


boston_team_cluster <- kmeans(boston_7 [,2:6,8] , 3, nstart = 20)
boston_team_cluster
plot( boston_7$yearID,boston_team_cluster$cluster)
clusplot(boston_7[,c(2:8)], boston_team_cluster$cluster, color=T, lwd=2)
dev.off()


# New York Cluster

newyork_7 <- newyork %>%
  select("yearID","ERA", "runsDera", "sb_cs", "err_gp", "hits_hr", "winMhomegames", "hr_hra")

newyork_team_cluster <- kmeans(newyork_7 [,2:5,7] , 4, nstart = 20)
newyork_team_cluster
plot( newyork_7$yearID,newyork_team_cluster$cluster)
clusplot(newyork_7[,c(2:8)], newyork_team_cluster$cluster, color=T, lwd=2)
dev.off()

#cleveland cluster

cleveland_7 <- cleveland %>%
  select("yearID","ERA", "runsDera", "sb_cs", "err_gp", "hits_hr", "winMhomegames", "hr_hra")

cleveland_team_cluster <- kmeans(cleveland_7 [,2:4,6] , 2, nstart = 20)
cleveland_team_cluster
plot( cleveland_7$yearID,cleveland_team_cluster$cluster)
clusplot(cleveland_7[,c(2:8)], cleveland_team_cluster$cluster, color=T, lwd=2)
dev.off()

#chicago cluster

chicago_7 <- chicago %>%
  select("yearID","ERA", "runsDera", "sb_cs", "err_gp", "hits_hr", "winMhomegames", "hr_hra")

chicago_team_cluster <- kmeans(cleveland_7 [,2:8] , 4, nstart = 20)
chicago_team_cluster
plot( chicago_7$yearID,chicago_team_cluster$cluster)
clusplot(chicago_7[,c(2:8)], chicago_team_cluster$cluster, color=T, lwd=2)
dev.off()

#philly cluster

philly_7 <- philly %>%
  select("yearID","ERA", "runsDera", "sb_cs", "err_gp", "hits_hr", "winMhomegames", "hr_hra")

philly_team_cluster <- kmeans(cleveland_7 [,2:8] , 2, nstart = 20)
philly_team_cluster
plot( philly_7$yearID,philly_team_cluster$cluster)
clusplot(philly_7[,c(2:8)], philly_team_cluster$cluster, color=T, lwd=2)
dev.off()


