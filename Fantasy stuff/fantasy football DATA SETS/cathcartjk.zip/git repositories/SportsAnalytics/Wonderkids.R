url <- 'https://fminside.net/football-manager-2019-wonderkids/'

webpage <- read_html(url)
  
wonderkids_gk <- html_nodes(webpage, 'td')  
wonderkids_gk <- html_table(wonderkids_gk)

head(wonderkids_gk)
View(wonderkids_gk)
  
